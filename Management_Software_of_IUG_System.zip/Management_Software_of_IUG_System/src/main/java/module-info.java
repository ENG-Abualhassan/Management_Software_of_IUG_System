module com.example.management_software_of_iug_system {
    requires java.sql;
    requires java.base;
    requires org.postgresql.jdbc;
    requires java.naming;
    requires javafx.fxml;
    requires javafx.controls;
    requires controlsfx;
    requires com.jfoenix;
    requires java.mail;
    requires javafx.media;
    requires javafx.web;
    requires javafx.graphics;
    requires javafx.base;
    requires java.desktop;
    opens com.example.management_software_of_iug_system to javafx.fxml;
    opens com.example.management_software_of_iug_system.admin;
    exports com.example.management_software_of_iug_system.admin;
    opens com.example.management_software_of_iug_system.sample to javafx.fxml;
    exports com.example.management_software_of_iug_system.sample;

}
