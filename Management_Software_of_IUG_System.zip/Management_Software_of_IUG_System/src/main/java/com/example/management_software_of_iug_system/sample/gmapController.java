package com.example.management_software_of_iug_system.sample;

import javafx.fxml.FXML;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;

import java.net.URL;
import java.util.ResourceBundle;

public class gmapController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private WebView gmap;
    private WebEngine e;

    @FXML
    void initialize() {
        e = gmap.getEngine();
        e.load("https://goo.gl/maps/4Fvb78PBiedoaskK8");
    }
}
