package com.example.management_software_of_iug_system.sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

import java.awt.*;
import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;

public class routineController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    void download(ActionEvent event) {
        try {
            System.out.println("opening pdf");
            File file = new File("C:\\Users\\alawael\\IdeaProjects\\Management_Software_of_IUG_System\\src\\main\\java\\com\\example\\management_software_of_iug_system\\Document\\SemesterWiseRoutine.pdf");
            if(file.exists())
                if(Desktop.isDesktopSupported()){
                    Desktop.getDesktop().open(file);
                }
                else
                    System.out.println("file not exist");
        }catch (Exception e){
            System.out.println(e);
        }



    }

    @FXML
    void initialize() {

    }
}
