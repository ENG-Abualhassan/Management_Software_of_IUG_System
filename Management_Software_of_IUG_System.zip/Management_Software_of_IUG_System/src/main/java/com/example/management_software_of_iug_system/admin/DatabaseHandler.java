package com.example.management_software_of_iug_system.admin;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.postgresql.ds.PGSimpleDataSource;


public class DatabaseHandler {
    private Connection con;
    public static void main(String[] args) {
        DatabaseHandler dh = new DatabaseHandler();
        dh.connect();
    }
    public Connection connect() {
        PGSimpleDataSource source = new PGSimpleDataSource();
        source.setServerName("localhost");
        source.setDatabaseName("IUG_Database");
        source.setUser("postgres");
        source.setPassword("850451hassan");
        source.setCurrentSchema("IUG_Schema");

        try {
            con = source.getConnection();
            System.out.println("Connected to server successfully");
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        return con;
    }
    public static ResultSet executeQuery(String query, Connection conn) {
        ResultSet result;
        Statement st;
        try {
            st = conn.createStatement();
            result = st.executeQuery(query);
        } catch (SQLException ex) {
            System.out.println("Exception at executeQuery:databaseHandler" + ex.getLocalizedMessage());
            return null;
        }
        return result;
    }
}