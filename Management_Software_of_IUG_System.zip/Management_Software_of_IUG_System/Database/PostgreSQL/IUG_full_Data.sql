CREATE TABLE admin (
                       "Admin Name" varchar(14) not null,
                       "Admin Work Hour" varchar(11),
                       "Admin Joining Date" varchar(20),
                       "ID" varchar(50) PRIMARY KEY,
                       "Password" int  not null ,
                       "Image" varchar(50)
);


INSERT INTO admin ("Admin Name", "Admin Work Hour", "Admin Joining Date", "ID", "Password",  "Image") VALUES
                                                                                                          ('Dr.Ahmed Mahdi', '9:30am-2pm', '11-March-2020', 'AhmedMahdi_DBMS_2023', 1234 , 'sample/images/Dr.Ahmed Mahdi.jpg'),
                                                                                                          ('Eng.Asama Zian', '10am-4pm', '28-January-2022', 'AsamaZian_DBMS_2023', 4567, 'sample/images/Eng.Asama zian.jpg');
CREATE TABLE course (
                        Cname varchar(100) not null,
                        Ccode varchar(100) primary key ,
                        Ccredit varchar(100),
                        Cdept varchar(32) not null
);

INSERT INTO course (Cname, Ccode, Ccredit, Cdept)
VALUES
    ('Discrete', '2100', '3.0', 'Computer Science and Engineering'),
    ('OOP', '2101', '3.0', 'Computer Science and Engineering'),
    ('EEE', '2102', '3.0', 'Computer Science and Engineering'),
    ('Mechanical', '2103', '3.0', 'Computer Science and Engineering'),
    ('Sdlab', '2104', '1.5', 'Computer Science and Engineering'),
    ('OOPlab', '2105', '1.5', 'Computer Science and Engineering'),
    ('EEELab', '2106', '1.5', 'Computer Science and Engineering'),
    ('MECHALab', '2107', '1.5', 'Computer Science and Engineering');

CREATE TABLE databasefile (
                              "Full Name" varchar(26) not null ,
                              "ID" varchar(12) primary key,
                              "Email" varchar(31),
                              "Mobile number" varchar(30),
                              "Present Address" varchar(55),
                              "Password" integer not null,
                              "Gender" varchar(30),
                              "Blood Group" varchar(30),
                              "Religion" varchar(20),
                              "Father Name" varchar(30),
                              "Mother name" varchar(30),
                              "Phone Number" varchar(30),
                              "Permanent Address" varchar(45),
                              "Guardian Name" varchar(30) not null,
                              "Guardian Mobile" varchar(30),
                              "Guardian Phone" varchar(30),
                              "Guardian Email" varchar(30) not null,
                              "First Name" varchar(30) not null,
                              "Last Name" varchar(30) not null,
                              "Birth Date" varchar(30),
                              "Year/Semester" varchar(30),
                              "Semester" varchar(30),
                              "Dept/School" varchar(45),
                              "Program" varchar(55),
                              "CGPA" numeric(3,2),
                              "Theory Section" varchar(30),
                              "Sessional Section" varchar(30),
                              "Advisor" varchar(30),
                              "picture" varchar(31),
                              "DOB" varchar(30)
);

INSERT INTO databasefile ("Full Name", "ID", "Email", "Mobile number", "Present Address", "Password", "Gender", "Blood Group", "Religion", "Father Name", "Mother name", "Phone Number", "Permanent Address", "Guardian Name", "Guardian Mobile", "Guardian Phone", "Guardian Email", "First Name", "Last Name", "Birth Date", "Year/Semester", "Semester", "Dept/School", "Program", "CGPA", "Theory Section", "Sessional Section", "Advisor", "picture", "DOB") VALUES
                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ('Tamima wahab', '19.01.04.051', 'Tamimawahab99@yahoo.com ', '1777334422', 'Gulshan 1,nikheton,road 1,block A', 1234, 'Female', 'O+', 'Islam', '', '', '', '', '', '', '', '', '', '', '', '2-1', 'Spring,2019', 'Department of Computer Science and Technology', 'Bachelor of Science in Computer Science and Engineering', '3.01', 'B', 'B1', 'Tahsin Aziz', '', ''),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ('Tanzina taher ', '19.01.04.053', 'Tanzina0taher@gmail.com', '1622880066', '19/A ware street, wari,dhaka-1203', 1234, 'Female', 'B+', 'Islam', '', '', '', '', '', '', '', '', '', '', '', '2-1', 'Spring,2019', 'Department of Computer Science and Technology', 'Bachelor of Science in Computer Science and Engineering', '3.02', 'B', 'B1', 'Tahsin Aziz', '', ''),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ('Busra Kamal Rafa', '19.01.04.055', 'rafa54464@gmail.com', '1992756555', '41/10,block-c ,chanmia housing, Mohammadpur, Dhaka-1207', 1234, 'Male', 'O+', 'Islam', '', '', '', '', '', '', '', '', '', '', '', '2-1', 'Spring,2019', 'Department of Computer Science and Technology', 'Bachelor of Science in Computer Science and Engineering', '3.03', 'B', 'B1', 'Tahsin Aziz', '', ''),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ('Md.Tareq Zaman', '19.01.04.056', 'tareqzaman777@gmail.com ', '1866162622', 'Tha -24,block A,khilgaon, Dhaka', 1234, 'Female', 'A+', 'Islam', '', '', '', '', '', '', '', '', '', '', '', '2-1', 'Spring,2019', 'Department of Computer Science and Technology', 'Bachelor of Science in Computer Science and Engineering', '3.04', 'B', 'B1', 'Tahsin Aziz', '', ''),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ('MD. Zabed Miandad ', '19.01.04.057', 'zabedmiandad200@gmail.com ', '1309033705', '9/8, North Pirerbag, Mirpur-2, Dhaka ', 1234, 'Male', 'B+', 'Islam', '', '', '', '', '', '', '', '', '', '', '', '2-1', 'Spring,2019', 'Department of Computer Science and Technology', 'Bachelor of Science in Computer Science and Engineering', '3.05', 'B', 'B1', 'Tahsin.Aziz', '', ''),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ('Rafiul Islam', '19.01.04.059', 'rafiulislam07@gmail.com', '1776777222', 'B/19, Block-E, Pallabi, Dhaka-1216', 1234, 'Male', 'AB-', 'Islam', '', '', '', '', '', '', '', '', '', '', '', '2-1', 'Spring,2019', 'Department of Computer Science and Technology', 'Bachelor of Science in Computer Science and Engineering', '3.06', 'B', 'B1', 'Tahsin Aziz', '', ''),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ('Tanvir Hasan', '19.01.04.061', 'tanvirhasan48@gmail.com', '1622880088', 'Dhanmondi, Dhaka', 1234, 'Male', 'B+', 'Islam', '', '', '', '', '', '', '', '', '', '', '', '2-1', 'Spring,2019', 'Department of Computer Science and Technology', 'Bachelor of Science in Computer Science and Engineering', '3.07', 'B', 'B1', 'Tahsin Aziz', '', ''),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ('Mehejabin Sultana', '19.01.04.062', 'mehejabin.sultana@gmail.com', '1777334433', 'Road 5, Uttara', 1234, 'Female', 'O+', 'Islam', '', '', '', '', '', '', '', '', '', '', '', '2-1', 'Spring,2019', 'Department of Computer Science and Technology', 'Bachelor of Science in Computer Science and Engineering', '3.08', 'B', 'B1', 'Tahsin Aziz', '', ''),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ('Nabila Fairooz', '19.01.04.065', 'nabilafairooz@gmail.com', '1622880066', '12/B, Block-C, Bashundhara Residential Area, Dhaka', 1234, 'Female', 'B+', 'Islam', '', '', '', '', '', '', '', '', '', '', '', '2-1', 'Spring,2019', 'Department of Computer Science and Technology', 'Bachelor of Science in Computer Science and Engineering', '3.09', 'B', 'B1', 'Tahsin Aziz', '', ''),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ('Sara Khan', '19.01.04.066', 'sara.khan@example.com', '1622777999', 'Gulshan, Dhaka', 1234, 'Female', 'A+', 'Islam', '', '', 'Khan Ahmed', '1622777888', 'Engineer', 'Farah Khan', '1622777777', 'Teacher', 'Ali Ahmed', '1622777666', 'Uncle', '2-1', 'Spring,2019', 'Department of Computer Science and Technology', 'Bachelor of Science in Computer Science and Engineering', '3.10', 'A', 'A1', 'Tahsin Aziz', '', ''),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ('Rahul Sharma', '19.01.04.067', 'rahul.sharma@example.com', '1777444555', 'Banani, Dhaka', 1234, 'Male', 'O-', 'Hindu', '', '', 'Rajesh Sharma', '1777444444', 'Businessman', 'Priya Sharma', '1777444333', 'Homemaker', 'Amit Sharma', '1777444222', 'Brother', '2-1', 'Spring,2019', 'Department of Computer Science and Technology', 'Bachelor of Science in Computer Science and Engineering', '3.12', 'A', 'A1', 'Tahsin Aziz', '', ''),
                                                                                                                                                                                                                                                                                                                                                                                                                                                                      ('Maria Rodriguez', '19.01.04.068', 'maria.rodriguez@example.com', '1622999888', 'Mirpur, Dhaka', 1234, 'Female', 'AB+', 'Christian', '', '', 'Carlos Rodriguez', '1622999777', 'Doctor', 'Isabella Rodriguez', '1622999666', 'Nurse', 'Juan Rodriguez', '1622999555', 'Uncle', '2-1', 'Spring,2019', 'Department of Computer Science and Technology', 'Bachelor of Science in Computer Science and Engineering', '3.08', 'B', 'B2', 'Tahsin Aziz', '', '');





CREATE TABLE evaluationform (
                                ID varchar(12) ,
                                "Faculty Name" varchar(13) not null,
                                Q1 integer,
                                Q2 integer,
                                Q3 integer,
                                Q4 integer,
                                Q5 integer,
                                Q6 integer,
                                Q7 integer,
                                Q8 integer,
                                Q9 integer,
                                Q10 integer
);

INSERT INTO evaluationform (ID, "Faculty Name", Q1, Q2, Q3, Q4, Q5, Q6, Q7, Q8, Q9, Q10)
VALUES
    ('19.01.04.065', 'IUG', 5, 5, 5, 5, 5, 5, 5, 5, 5, 5),
    ('19.01.04.058', 'IUG', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1),
    ('19.01.04.058', 'IUG', 2, 3, 2, 2, 2, 2, 2, 3, 3, 3),
    ('19.01.04.065', 'IUG', 2, 2, 2, 2, 2, 2, 2, 2, 2, 2),
    ('19.01.04.065', 'IUG', 3, 2, 3, 2, 3, 3, 2, 3, 2, 3);

CREATE TABLE examtimedatabase (
                                  "Date" varchar(14) DEFAULT NULL,
                                  "Time" varchar(8) DEFAULT NULL,
                                  "Exam Name" varchar(9) DEFAULT NULL
);

INSERT INTO examtimedatabase ("Date", "Time", "Exam Name") VALUES
                                                               ('18 April, 2023', '12:30 PM', 'CSE 2204'),
                                                               ('20 April, 2023', '1:30 PM', 'Math 2205'),
                                                               ('21 April, 2023', '2:30 PM', 'CSE 2206'),
                                                               ('23 April, 2023', '3:30 PM', 'EEE 2207'),
                                                               ('26 April, 2023', '4:30 PM', 'CSE 2208'),
                                                               ('29 April, 2023', '5:30 PM', 'HUM 2209'),
                                                               ('2 May, 2023', '6:30 PM', 'CSE 2210'),
                                                               ('4 May, 2023', '7:30 PM', 'CSE 2211'),
                                                               ('8 May, 2023', '8:30 PM', 'CSE 2104');


CREATE TABLE facultydatabase (
                                 "FACALTY NAME" varchar(20),
                                 "DEPARTMENT" varchar(100),
                                 "RESPECTIVE COURSE ID" varchar(20),
                                 "CONTACT NO" varchar(100),
                                 "EMAIL ADDRESS" varchar(100),
                                 "Password" varchar(100) primary key
);

INSERT INTO facultydatabase ("FACALTY NAME", "DEPARTMENT", "RESPECTIVE COURSE ID", "CONTACT NO", "EMAIL ADDRESS", "Password")
VALUES
    ('Anik Chowdhury', 'CSE', 'CSE 2106, CSE 2115', '18804565', 'anik@aust.edu', '1234'),
    ('Tahsin Aziz', 'CSE', 'CSE 2106, CSE 2116', '44848788', 'aziz@aust.edu', '3214'),
    ('Raqeebir Rab', 'CSE', 'CSE 2106, CSE 2117', '56578896', 'raqeebir@aust.edu', '1241'),
    ('Qamrun Nahar Eity', 'CSE', 'CSE 2106, CSE 2119', '45636464', 'eity@aust.edu', '1032'),
    ('Tayfur Rahman Pathan', 'EEE', 'EEE 2106, EEE 2120', '18804565', 'pathan@aust.edu', '2222'),
    ('Enam Hossain', 'CSE', 'CSE 2106, CSE 2121', '18804565', 'enam@aust.edu', '1111'),
    ('Mohsan Uddin', 'ME', 'ME 2106, ME 2122', '78678786', 'mohsan@aust.edu', '4213'),
    ('Sanjida Sultana', 'HUM', 'HUM 2106, HUM 2123', '67676877', 'sanjida@aust.edu', '6521'),
    ('Samsad Jahan', 'MATH', 'MATH 2106, MATH 2124', '86864684', 'samsad@aust.edu', '3211'),
    ('Akash Ranjon', 'BBA', 'MKC 2206, GEN 2105', '46456846', 'akash@aust.edu', '45312');

CREATE TABLE holidaysdatabase (
                                  Date varchar(17),
                                  Holiday varchar(30)
);

INSERT INTO holidaysdatabase (Date, Holiday)
VALUES
    ('2023-01-01', 'New year''s Day (Optional)'),
    ('2023-01-10', 'Bangabandhu Homecoming Day'),
    ('2023-02-16', 'Saraswati Puja'),
    ('2023-02-17', 'Ash Wednesday (Optional)'),
    ('2023-02-21', 'Language Martyr''s Day'),
    ('2023-02-27', 'Maghi Purnima (Optional)'),
    ('2023-03-02', 'National Flag Day (Observance)'),
    ('2023-03-11', 'Shab -e -Meraj, Maha Shivratri'),
    ('2023-03-17', 'Bnagabadhu''s Birthday'),
    ('2023-03-26', 'Independence Day'),
    ('2023-03-29', 'Holi(Hindu Holiday)'),
    ('2023-04-04', 'Easter Day (Optional)'),
    ('2023-04-14', 'Bengali New year'),
    ('2023-05-01', 'May Day');


CREATE TABLE newaccountrequest (
                                   ID varchar(20) primary key not null,
                                   Email varchar(40) not null
);

INSERT INTO newaccountrequest (ID, Email) VALUES
                                              ('19.01.04.101', 'mathanosto@yahoo.com'),
                                              ('54165', '5641651456'),
                                              ('19.01.05.996', 'ghjhkgkjhljkh'),
                                              ('17.01.04.0555', 'sabyu'),
                                              ('18.02.04.006', 'vondo@gmail.com');

CREATE TABLE notice (
                        "Notice No" integer primary key not null,
                        "Notice Title" varchar(100),
                        "Date" varchar(100),
                        "Link" varchar(200)
);

INSERT INTO notice ("Notice No", "Notice Title", "Date", "Link")
VALUES
    (20210898, 'Notice For Final Year Elective Subject Choice', '2021-01-04', ''),
    (202110899, 'Admission Notice', '2021-02-04', ''),
    (565910901, 'CSE Football Tournament Guidelines', '2021-04-04', ''),
    (747810902, 'CSE Annual Rag Day Guidelines', '2021-05-04', ''),
    (929710903, 'Notice For Aust Education Email ID', '2021-06-04', ''),
    (929710905, 'Test1', '2023-04-02', ''),
    (929710906, 'Test2', '2023-04-02', '');

CREATE TABLE result (
                        ID varchar(12) primary key,
                        DISCRETE int,
                        OOP int,
                        EEE int,
                        MATH int,
                        MECHANICAL int,
                        Sdlab int,
                        OOPlab int,
                        EEElab int,
                        MECHAlab int
);

INSERT INTO result (ID, DISCRETE, OOP, EEE, MATH, MECHANICAL, Sdlab, OOPlab, EEElab, MECHAlab) VALUES
                                                                                                   ('19.01.04.055', 75, 75, 80, 77, 73, 80, 77, 77, 77),
                                                                                                   ('19.01.04.058', 76, 76, 82, 80, 75, 80, 76, 78, 76),
                                                                                                   ('19.01.04.065', 77, 80, 80, 67, 76, 80, 80, 77, 76),
                                                                                                   ('19.01.04.070', 80, 76, 86, 80, 81, 80, 77, 76, 78),
                                                                                                   ('18.01.04.145', 75, 70, 72, 68, 77, 70, 74, 76, 72),
                                                                                                   ('19.01.04.056', 100, 100, 100, 100, 100, 100, 100, 100, 100);

